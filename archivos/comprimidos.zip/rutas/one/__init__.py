def init(db, api, **_):
    print(f"Soy el paquete uno, {db} {api}")
