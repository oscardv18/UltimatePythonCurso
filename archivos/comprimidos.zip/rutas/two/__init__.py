def init(db, api, **_):
    print(f"Soy el paquete dos, {db} {api}")
