try:
    n1 = int(input("Ingresa un numero: "))
    print(n1)
except:
    print("Ocurrio un error :(")