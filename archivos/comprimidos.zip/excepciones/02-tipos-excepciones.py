try:
    n1 = int(input("Ingrese un numero: "))
    asdf
except ValueError as e:
    print("Ingrese un numero valido!")
except NameError as e :
    print("Ocurrio un error!")
