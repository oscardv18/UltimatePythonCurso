mascotas = ["Wolfgang", "Pelusa", "Pulga", "Copito"]
mascotas.append("Pelusin")
# # print(mascotas[0])
# # mascotas[0] = "Bicho"
# # print(mascotas)
# # print(mascotas[:3])
# # print(mascotas[2:])
# # print(mascotas[-1])
# print(mascotas[1:3:2])

numeros = list(range(21))
print(numeros)
print(numeros[::2])
print(numeros[1::2])

print(mascotas)
print(mascotas[1:3:2])
