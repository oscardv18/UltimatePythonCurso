numeros = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["chanchito", "feliz"]
palabrasFelices = ["chanchito", "feliz", "oscar", "feliz", "Python"]
booleans = [True, False, True]
matriz = [[1, 0], [0, 1]]
# Para que dentro de una lista hallan 10 ceros o cualquier otro elemento que queramos, se utiliza esta forma:
ceros = [0] * 10
print(ceros)
alfanumerico = numeros + letras
rango = list(range(1, 11))
chars = list("Hola Mundo")
print(rango)
print(chars)
