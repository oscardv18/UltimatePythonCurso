mascotas = ["Pelusa", "Lusin", "Yuni", "Catira", "Gambeta"]

for indice, mascota in enumerate(mascotas):
    print(indice, mascota)
