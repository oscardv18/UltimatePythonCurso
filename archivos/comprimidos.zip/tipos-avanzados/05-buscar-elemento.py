mascotas = ["Pelusa", "Lusin", "Pelusa", "Yuni", "Catira", "Gambeta"]

print(mascotas.count("Pelusa"))
if "Pelusa" in mascotas:
    print(mascotas.index("Pelusa"))
