mascotas = ["Pelusa", "Lusin", "Yuni",
            "Catira", "Gambeta", "Karen", "Pulga", "Wolfgang"]

mascotas.insert(1, "Cordero")
mascotas.append("Chanchito Feliz")
print(mascotas)

mascotas.remove("Wolfgang")
print(mascotas)
mascotas.pop()
print(mascotas)
del mascotas[6]
print(mascotas)
mascotas.clear()
print(mascotas)
