def suma(a, b):
    result = a + b
    return result


c = suma(1, 2)
d = suma(c, 3)

print(d)
