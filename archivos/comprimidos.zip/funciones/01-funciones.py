def hola(name, surname=""):
    print("Hello World")
    print(f"Bienvenido {name} {surname}")


hola("Oscar", "Diaz")
hola(surname="Diaz", name="Oscar")
