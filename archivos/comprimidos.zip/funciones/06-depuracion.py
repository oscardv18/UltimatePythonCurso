def largo(texto):
    result = 0
    for _ in texto:
        result += 1
    return result


print("chanchito")
l = largo("Hola Mundo")
print(l)
