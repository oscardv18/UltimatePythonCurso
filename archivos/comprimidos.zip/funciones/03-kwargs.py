def get_products(**datos):
    print(datos["id"], datos["name"])


get_products(id="1312", name="iPhone",
             desc="Un nuevo tlf igual que el anterior pero mas caro")
