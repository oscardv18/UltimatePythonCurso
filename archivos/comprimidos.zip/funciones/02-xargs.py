def sumar(*nums):
    result = 0
    for num in nums:
        result += num
    print(result)


sumar(1, 2)
sumar(1, 2, 3, 4, 5)
sumar(1, 2, 3, 4, 5, 12, 325)
