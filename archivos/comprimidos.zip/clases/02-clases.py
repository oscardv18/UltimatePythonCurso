class MiPerro:
    def habla(self):
        print("Guau!")


mi_perro = MiPerro()
mi_perro.habla()

print(isinstance(mi_perro, MiPerro))