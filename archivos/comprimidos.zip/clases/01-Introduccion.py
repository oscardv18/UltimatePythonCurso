# Clase: Plano de construccion
# Objeto: Instancia de una Clase