"""
Introduccion a Python
"""

print("Hello World!")
print("El weta" * 4)
Name = "Oscar"
