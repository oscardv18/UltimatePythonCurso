nombre_curso = "Ultimate Python"
NombreCurso = "Hola desde Python"
print(nombre_curso)

valorSi = True
valorNo = False

number = 5000
flotante = 9.9
