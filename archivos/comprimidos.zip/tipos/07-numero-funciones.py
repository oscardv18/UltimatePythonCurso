import math

print(round(1.3))
print(round(1.7))
print(abs(-77))
print(abs(55))

print(math.ceil(1.1))
print(math.floor(1.9999))
print(math.isnan(23))
print(math.pow(10, 3))
print(math.sqrt(9))
