nombre_curso = "Ultimate Python"
descripcion_curso = """
Ultimate Python,
este es el curso que necesitas para conseguir
trabajo como desarrollador python
"""
print(len(nombre_curso))
print(nombre_curso[0:8])
print(nombre_curso[9:])
print(nombre_curso[:8])
print(nombre_curso[:-2])
