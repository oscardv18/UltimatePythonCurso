nombre = "Oscar"
apellido = "Diaz"
nombre_completo = f"{nombre} {apellido}"
print(nombre_completo)
