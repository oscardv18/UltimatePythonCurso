curso = "Ultimate \"Python\""
print(curso)
