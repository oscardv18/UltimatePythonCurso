numero = 2  # Numero entero => Integer
decimal = 2.2  # Float => decimal
imaginario = 2 + 2j  # 2 + 2i -> Numero imaginario
