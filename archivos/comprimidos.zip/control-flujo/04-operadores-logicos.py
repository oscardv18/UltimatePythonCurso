# and, or, not

gas = False
encendido = True
edad = 19

if not gas and (encendido or edad > 18):
    print("Puedes avanzar!")
