edad = 55

if edad > 65:
    print("Puedes entrar con un super descuento!")
elif edad > 54:
    print("Puedes entrar con descuento!")
elif edad > 17:
    print("Puedes entrar")

print("Listo")
