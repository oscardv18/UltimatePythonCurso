for i in range(3):
    for j in range(2):
        print(f"i: {i}, j: {j}")
