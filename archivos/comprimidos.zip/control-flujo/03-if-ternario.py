edad = 15

message = "Es mayor" if edad > 18 else "Es Menor"

print(message)
